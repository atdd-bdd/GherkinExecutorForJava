package test.java.gherkinexecutor.Feature_Calculator;
import org.junit.jupiter.api.Test;
import java.util.List;
class Feature_Calculator{


    @Test
    void test_Scenario_Add_two_numbers(){
         Feature_Calculator_glue feature_Calculator_glue_object = new Feature_Calculator_glue();

        List<Calculation> objectList1 = List.of(
             new Calculation.Builder()
                .setNumber1("2")
                .setNumber2("3")
                .setResult("5")
                .build()
            , new Calculation.Builder()
                .setNumber1("10")
                .setNumber2("20")
                .setResult("30")
                .build()
            , new Calculation.Builder()
                .setNumber1("-1")
                .setNumber2("1")
                .setResult("0")
                .build()
            );
        feature_Calculator_glue_object.When_I_add_two_numbers_I_get_the_result(objectList1);
        }
    }

