package test.java.gherkinexecutor.Feature_Data_Definition_Error;
import org.junit.jupiter.api.Test;
import java.util.List;
class Feature_Data_Definition_Error{


    @Test
    void test_Scenario_Simple_Table_with_int_bad(){
         Feature_Data_Definition_Error_glue feature_Data_Definition_Error_glue_object = new Feature_Data_Definition_Error_glue();

        List<ATest> objectList1 = List.of(
             new ATest.Builder()
                .setAnInt("q")
                .setAString("something")
                .setADouble("1.1")
                .build()
            );
        feature_Data_Definition_Error_glue_object.Given_table_is(objectList1);
        }
    @Test
    void test_Scenario_Simple_Table_with_double_bad(){
         Feature_Data_Definition_Error_glue feature_Data_Definition_Error_glue_object = new Feature_Data_Definition_Error_glue();

        List<ATest> objectList1 = List.of(
             new ATest.Builder()
                .setAnInt("1")
                .setAString("something")
                .setADouble("r")
                .build()
            );
        feature_Data_Definition_Error_glue_object.Given_table_is(objectList1);
        }
    @Test
    void test_Scenario_Simple_Table_with_initializer_bad(){
         Feature_Data_Definition_Error_glue feature_Data_Definition_Error_glue_object = new Feature_Data_Definition_Error_glue();

        List<ATestBad> objectList1 = List.of(
             new ATestBad.Builder()
                .setAnInt("1")
                .build()
            );
        feature_Data_Definition_Error_glue_object.Given_table_is_bad_initializer(objectList1);
        }
    }

