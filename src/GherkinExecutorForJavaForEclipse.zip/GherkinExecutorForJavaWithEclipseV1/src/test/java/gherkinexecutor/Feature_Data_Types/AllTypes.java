package test.java.gherkinexecutor.Feature_Data_Types;
import java.util.*;
class AllTypes{
    String anInt = "0";
    String aDouble = "0.0";
    String aChar = "x";
    String achar = "y";
    public AllTypes() { }
    public AllTypes(
        String anInt
        ,String aDouble
        ,String aChar
        ,String achar
        ){
        this.anInt = anInt;
        this.aDouble = aDouble;
        this.aChar = aChar;
        this.achar = achar;
        }
    @Override
    public boolean equals (Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass())
             return false;
        AllTypes _AllTypes = (AllTypes) o;
            boolean result = true;
         if (
             !this.anInt.equals("?DNC?")
                && !_AllTypes.anInt.equals("?DNC?"))
                if (! _AllTypes.anInt.equals(this.anInt)) result = false;
         if (
             !this.aDouble.equals("?DNC?")
                && !_AllTypes.aDouble.equals("?DNC?"))
                if (! _AllTypes.aDouble.equals(this.aDouble)) result = false;
         if (
             !this.aChar.equals("?DNC?")
                && !_AllTypes.aChar.equals("?DNC?"))
                if (! _AllTypes.aChar.equals(this.aChar)) result = false;
         if (
             !this.achar.equals("?DNC?")
                && !_AllTypes.achar.equals("?DNC?"))
                if (! _AllTypes.achar.equals(this.achar)) result = false;
             return result;  }
    public static class Builder {
        private String anInt = "0";
        private String aDouble = "0.0";
        private String aChar = "x";
        private String achar = "y";
        public Builder setAnInt(String anInt) {
            this.anInt = anInt;
            return this;
            }
        public Builder setADouble(String aDouble) {
            this.aDouble = aDouble;
            return this;
            }
        public Builder setAChar(String aChar) {
            this.aChar = aChar;
            return this;
            }
        public Builder setAchar(String achar) {
            this.achar = achar;
            return this;
            }
        public Builder  setCompare() {
            anInt = "?DNC?";
            aDouble = "?DNC?";
            aChar = "?DNC?";
            achar = "?DNC?";
            return this;
            }
        public AllTypes build(){
             return new AllTypes(
                 anInt
                 ,aDouble
                 ,aChar
                 ,achar
                );   } 
        } 
    @Override
    public String toString() {
        return "AllTypes {"
        +"anInt = " + anInt + " "
        +"aDouble = " + aDouble + " "
        +"aChar = " + aChar + " "
        +"achar = " + achar + " "
            + "} " + "\n"; }  
    public String toJson() {
        return " {"
        +""+"anInt:" + "\"" + anInt + "\""
        +","+"aDouble:" + "\"" + aDouble + "\""
        +","+"aChar:" + "\"" + aChar + "\""
        +","+"achar:" + "\"" + achar + "\""
            + "} " + "\n"; }  
        public static AllTypes fromJson(String json) {
              AllTypes instance = new AllTypes();

              	json = json.replaceAll("\\s", "");
                String[] keyValuePairs = json.replace("{", "").replace("}", "").split(",");

                // Iterate over the key-value pairs
                for (String pair : keyValuePairs) {
                    // Split each pair by the colon
                    String[] entry = pair.split(":");

                    // Remove the quotes from the key and value
                    String key = entry[0].replace("\"", "").trim();
                    String value = entry[1].replace("\"", "").trim();


          // Assign the value to the corresponding field
                    switch (key) {
              case "anInt":
                  instance.anInt = value;
                  break;
              case "aDouble":
                  instance.aDouble = value;
                  break;
              case "aChar":
                  instance.aChar = value;
                  break;
              case "achar":
                  instance.achar = value;
                  break;
        				default:
        				    System.err.println("Invalid JSON element " + key);
                    }
                }
                return instance;
            }


             public static String listToJson(List<AllTypes> list) {
                 StringBuilder jsonBuilder = new StringBuilder();
                 jsonBuilder.append("[");

                 for (int i = 0; i < list.size(); i++) {
                     jsonBuilder.append(list.get(i).toJson());
                     if (i < list.size() - 1) {
                         jsonBuilder.append(",");
                     }
                 }

                 jsonBuilder.append("]");
                 return jsonBuilder.toString();
             }

                        public static List<AllTypes> listFromJson(String json) {
                            List<AllTypes> list = new ArrayList<>();
                    		json = json.replaceAll("\s", "");
                    		json = json.replaceAll("\\[","").replaceAll("]","");
                            String[] jsonObjects = json.split("(?<=\\}),\\s*(?=\\{)");
                            for (String jsonObject : jsonObjects) {
                                 list.add(AllTypes.fromJson(jsonObject));
                                 }
                            return list;
                        }

    AllTypesInternal toAllTypesInternal() {
        return new AllTypesInternal(
         Integer.parseInt(anInt)
        , Double.valueOf(aDouble)
        , Character.valueOf( aChar.length() > 0 ?aChar.charAt(0) : ' ')
        , ( achar.length() > 0 ?achar.charAt(0) : ' ')
        ); }
    }
