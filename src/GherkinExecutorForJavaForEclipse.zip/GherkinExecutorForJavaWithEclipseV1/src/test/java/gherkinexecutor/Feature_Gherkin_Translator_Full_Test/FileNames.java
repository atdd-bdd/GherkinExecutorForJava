package test.java.gherkinexecutor.Feature_Gherkin_Translator_Full_Test;
import java.util.*;
class FileNames{
    String expected = "NoFileName";
    String actual = "NoFileName";
    public FileNames() { }
    public FileNames(
        String expected
        ,String actual
        ){
        this.expected = expected;
        this.actual = actual;
        }
    @Override
    public boolean equals (Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass())
             return false;
        FileNames _FileNames = (FileNames) o;
            boolean result = true;
         if (
             !this.expected.equals("?DNC?")
                && !_FileNames.expected.equals("?DNC?"))
                if (! _FileNames.expected.equals(this.expected)) result = false;
         if (
             !this.actual.equals("?DNC?")
                && !_FileNames.actual.equals("?DNC?"))
                if (! _FileNames.actual.equals(this.actual)) result = false;
             return result;  }
    public static class Builder {
        private String expected = "NoFileName";
        private String actual = "NoFileName";
        public Builder setExpected(String expected) {
            this.expected = expected;
            return this;
            }
        public Builder setActual(String actual) {
            this.actual = actual;
            return this;
            }
        public Builder  setCompare() {
            expected = "?DNC?";
            actual = "?DNC?";
            return this;
            }
        public FileNames build(){
             return new FileNames(
                 expected
                 ,actual
                );   } 
        } 
    @Override
    public String toString() {
        return "FileNames {"
        +"expected = " + expected + " "
        +"actual = " + actual + " "
            + "} " + "\n"; }  
    public String toJson() {
        return " {"
        +""+"expected:" + "\"" + expected + "\""
        +","+"actual:" + "\"" + actual + "\""
            + "} " + "\n"; }  
        public static FileNames fromJson(String json) {
              FileNames instance = new FileNames();

              	json = json.replaceAll("\\s", "");
                String[] keyValuePairs = json.replace("{", "").replace("}", "").split(",");

                // Iterate over the key-value pairs
                for (String pair : keyValuePairs) {
                    // Split each pair by the colon
                    String[] entry = pair.split(":");

                    // Remove the quotes from the key and value
                    String key = entry[0].replace("\"", "").trim();
                    String value = entry[1].replace("\"", "").trim();


          // Assign the value to the corresponding field
                    switch (key) {
              case "expected":
                  instance.expected = value;
                  break;
              case "actual":
                  instance.actual = value;
                  break;
        				default:
        				    System.err.println("Invalid JSON element " + key);
                    }
                }
                return instance;
            }


             public static String listToJson(List<FileNames> list) {
                 StringBuilder jsonBuilder = new StringBuilder();
                 jsonBuilder.append("[");

                 for (int i = 0; i < list.size(); i++) {
                     jsonBuilder.append(list.get(i).toJson());
                     if (i < list.size() - 1) {
                         jsonBuilder.append(",");
                     }
                 }

                 jsonBuilder.append("]");
                 return jsonBuilder.toString();
             }

                        public static List<FileNames> listFromJson(String json) {
                            List<FileNames> list = new ArrayList<>();
                    		json = json.replaceAll("\s", "");
                    		json = json.replaceAll("\\[","").replaceAll("]","");
                            String[] jsonObjects = json.split("(?<=\\}),\\s*(?=\\{)");
                            for (String jsonObject : jsonObjects) {
                                 list.add(FileNames.fromJson(jsonObject));
                                 }
                            return list;
                        }

    }
