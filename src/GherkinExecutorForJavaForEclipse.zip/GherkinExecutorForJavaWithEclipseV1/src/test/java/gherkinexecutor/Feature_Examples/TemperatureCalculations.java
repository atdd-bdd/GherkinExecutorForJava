package test.java.gherkinexecutor.Feature_Examples;

public class TemperatureCalculations {
    static int convertFahrenheitToCelsius(int input) {
        return ((input - 32) * 5) / 9;
    }
}



