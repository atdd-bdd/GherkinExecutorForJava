/**
 * 
 */
/**
 * @author user
 *
 */
module GherkinExecutorForJavaWithEclipseV1 {
	requires org.junit.jupiter.api;
}